# encoding: utf-8
# module _testimportmultiple
# from (pre-generated)
# by generator 1.147
""" _testimportmultiple doc """
# no imports

# no functions
# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x000001C2B3C4B430>'

__spec__ = None # (!) real value is "ModuleSpec(name='_testimportmultiple', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x000001C2B3C4B430>, origin='C:\\\\BuildAgent\\\\system\\\\.persistent_cache\\\\pythons\\\\python38\\\\DLLs\\\\_testimportmultiple.pyd')"

